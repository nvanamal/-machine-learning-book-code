# LINEAR REGRESSION | EXAMPLE A
# Basic fit and held-out prediction
# Dr. Nagendrababu Vanamala

from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error, r2_score
X, y = make_regression(n_samples=600, n_features=4,
                       noise=15, random_state=42)
Xtr, Xte, ytr, yte = train_test_split(
    X, y, test_size=0.2, random_state=42)
model = LinearRegression()
model.fit(Xtr, ytr)
pred = model.predict(Xte)
print("MAE:", mean_absolute_error(yte, pred))
print("R2:", r2_score(yte, pred))
print("Slopes:", model.coef_)
print("Intercept:", model.intercept_)
