# LINEAR REGRESSION | EXAMPLE C
# OLS cross-validation on training data
# Dr. Nagendrababu Vanamala

from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error
X, y = make_regression(n_samples=450, n_features=6,
                       noise=20, random_state=42)
Xtr, Xte, ytr, yte = train_test_split(X, y, random_state=42)
model = LinearRegression()
scores = cross_val_score(model, Xtr, ytr, cv=3,
                         scoring="neg_mean_absolute_error")
print("CV MAE:", -scores.mean())
model.fit(Xtr, ytr)
print("Test MAE:", mean_absolute_error(yte, model.predict(Xte)))
