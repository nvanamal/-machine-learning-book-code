# LINEAR REGRESSION | EXAMPLE B
# Polynomial regression for a curved target
# Dr. Nagendrababu Vanamala

import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import PolynomialFeatures
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_absolute_error
rng = np.random.default_rng(42)
X = rng.uniform(-3, 3, size=(400, 1))
y = 2 * X[:, 0] ** 2 + rng.normal(size=400)
Xtr, Xte, ytr, yte = train_test_split(X, y, random_state=42)
model = make_pipeline(PolynomialFeatures(2, include_bias=False),
                      LinearRegression())
model.fit(Xtr, ytr)
print("Polynomial MAE:", mean_absolute_error(yte, model.predict(Xte)))
