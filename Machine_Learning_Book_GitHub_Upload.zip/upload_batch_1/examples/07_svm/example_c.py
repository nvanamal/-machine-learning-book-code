# SUPPORT VECTOR MACHINE (SVM) | EXAMPLE C
# Linear SVM on multiclass inputs
# Dr. Nagendrababu Vanamala

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.svm import LinearSVC
from sklearn.metrics import classification_report
X, y = load_iris(return_X_y=True)
Xtr, Xte, ytr, yte = train_test_split(X, y,
    stratify=y, random_state=42)
model = make_pipeline(StandardScaler(), LinearSVC(C=1, max_iter=5000))
model.fit(Xtr, ytr)
print(classification_report(yte, model.predict(Xte), zero_division=0))
