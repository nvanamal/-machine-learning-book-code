# RIDGE, LASSO & ELASTIC NET | EXAMPLE A
# Basic fit and held-out prediction
# Dr. Nagendrababu Vanamala

from sklearn.datasets import make_regression
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import Ridge
from sklearn.metrics import mean_absolute_error
X, y = make_regression(n_samples=600, n_features=12,
                       noise=20, random_state=42)
Xtr, Xte, ytr, yte = train_test_split(X, y,
                       test_size=0.2, random_state=42)
model = make_pipeline(StandardScaler(), Ridge(alpha=10))
model.fit(Xtr, ytr)
print("MAE:", mean_absolute_error(yte, model.predict(Xte)))
# Substitute Lasso(alpha=...) or ElasticNet(...)
# Tune alpha with cross-validation on Xtr only.
