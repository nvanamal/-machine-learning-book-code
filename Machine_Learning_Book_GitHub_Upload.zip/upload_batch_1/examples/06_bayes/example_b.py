# NAIVE BAYES | EXAMPLE B
# Multinomial NB for text counts
# Dr. Nagendrababu Vanamala

from sklearn.pipeline import make_pipeline
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
texts = ["win cash prize", "claim free money", "meeting tomorrow",
         "project team update", "free cash offer", "team meeting notes"]
y = [1, 1, 0, 0, 1, 0]
model = make_pipeline(CountVectorizer(), MultinomialNB(alpha=1))
model.fit(texts, y)
print(model.predict(["free cash", "project meeting"]))
# Tiny language demonstration; not an accuracy benchmark.
