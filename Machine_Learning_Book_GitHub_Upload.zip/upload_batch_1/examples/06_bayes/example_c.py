# NAIVE BAYES | EXAMPLE C
# Bernoulli NB for binary features
# Dr. Nagendrababu Vanamala

from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import BernoulliNB
from sklearn.metrics import balanced_accuracy_score
X, y = make_classification(n_samples=450, n_features=8,
    n_informative=4, random_state=42)
X = (X > 0).astype(int)  # fixed threshold, binary inputs
Xtr, Xte, ytr, yte = train_test_split(X, y,
    stratify=y, random_state=42)
model = BernoulliNB(alpha=1).fit(Xtr, ytr)
print(balanced_accuracy_score(yte, model.predict(Xte)))
