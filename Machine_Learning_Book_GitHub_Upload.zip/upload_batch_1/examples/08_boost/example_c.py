# GRADIENT BOOSTING | EXAMPLE C
# Histogram boosting with missing inputs
# Dr. Nagendrababu Vanamala

import numpy as np
from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split
from sklearn.ensemble import HistGradientBoostingClassifier
from sklearn.metrics import balanced_accuracy_score
X, y = make_classification(n_samples=450, n_features=8,
    n_informative=4, random_state=42)
X[np.random.default_rng(42).random(X.shape) < 0.05] = np.nan
Xtr, Xte, ytr, yte = train_test_split(X, y,
    stratify=y, random_state=42)
model = HistGradientBoostingClassifier(max_iter=60, random_state=42)
model.fit(Xtr, ytr)
print(balanced_accuracy_score(yte, model.predict(Xte)))
