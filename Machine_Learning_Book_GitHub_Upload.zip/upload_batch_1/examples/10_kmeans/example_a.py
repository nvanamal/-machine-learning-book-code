# K-MEANS CLUSTERING | EXAMPLE A
# Cluster and measure silhouette
# Dr. Nagendrababu Vanamala

from sklearn.datasets import make_blobs
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
X, _ = make_blobs(n_samples=500, centers=3,
                 cluster_std=0.7, random_state=42)
model = make_pipeline(StandardScaler(),
    KMeans(n_clusters=3, n_init=10, random_state=42))
labels = model.fit_predict(X)
Xs = model.named_steps["standardscaler"].transform(X)
print("Silhouette:", silhouette_score(Xs, labels))
print("Cluster counts:", __import__("numpy").bincount(labels))
# Also inspect stability and domain usefulness.
