# K-MEANS CLUSTERING | EXAMPLE C
# Compare candidate cluster counts
# Dr. Nagendrababu Vanamala

from sklearn.datasets import make_blobs
from sklearn.preprocessing import StandardScaler
from sklearn.cluster import KMeans
from sklearn.metrics import silhouette_score
X, _ = make_blobs(n_samples=400, centers=3, random_state=42)
X = StandardScaler().fit_transform(X)
for k in [2, 3, 4, 5]:
    labels = KMeans(n_clusters=k, n_init=10,
                    random_state=42).fit_predict(X)
    print(k, silhouette_score(X, labels))
# Internal exploratory scores; also check stability and meaning.
