# K-MEANS CLUSTERING | EXAMPLE B
# Color grouping as image quantization
# Dr. Nagendrababu Vanamala

import numpy as np
from sklearn.cluster import KMeans
rng = np.random.default_rng(42)
# A synthetic RGB image; each pixel is a 3-feature vector.
image = rng.random((20, 20, 3))
pixels = image.reshape(-1, 3)
model = KMeans(n_clusters=4, n_init=10, random_state=42)
labels = model.fit_predict(pixels)
compressed = model.cluster_centers_[labels].reshape(image.shape)
print("Original/compressed shapes:", image.shape, compressed.shape)
print("Number of palette colors:", len(model.cluster_centers_))
