# LOGISTIC REGRESSION | EXAMPLE C
# Training-only CV for binary classification
# Dr. Nagendrababu Vanamala

from sklearn.datasets import make_classification
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import balanced_accuracy_score
X, y = make_classification(n_samples=450, n_features=8,
    n_informative=4, random_state=42)
Xtr, Xte, ytr, yte = train_test_split(X, y,
    stratify=y, random_state=42)
model = make_pipeline(StandardScaler(), LogisticRegression(max_iter=1000))
scores = cross_val_score(model, Xtr, ytr, cv=3,
    scoring="balanced_accuracy")
print("Training CV:", scores.mean())
model.fit(Xtr, ytr)
print("Test:", balanced_accuracy_score(yte, model.predict(Xte)))
