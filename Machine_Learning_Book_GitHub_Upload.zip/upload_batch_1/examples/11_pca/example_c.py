# PRINCIPAL COMPONENT ANALYSIS (PCA) | EXAMPLE C
# PCA inside a predictive validation pipeline
# Dr. Nagendrababu Vanamala

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LogisticRegression
X, y = load_iris(return_X_y=True)
Xtr, Xte, ytr, yte = train_test_split(X, y,
    stratify=y, random_state=42)
model = make_pipeline(StandardScaler(), PCA(n_components=2),
                      LogisticRegression(max_iter=1000))
print("CV accuracy:", cross_val_score(model, Xtr, ytr, cv=3).mean())
model.fit(Xtr, ytr)
print("Test accuracy:", model.score(Xte, yte))
