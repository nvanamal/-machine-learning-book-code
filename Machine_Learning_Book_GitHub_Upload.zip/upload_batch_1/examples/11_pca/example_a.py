# PRINCIPAL COMPONENT ANALYSIS (PCA) | EXAMPLE A
# Project onto two PCA components
# Dr. Nagendrababu Vanamala

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
X, _ = load_iris(return_X_y=True)
Xtr, Xte = train_test_split(X, test_size=0.2,
                           random_state=42)
model = make_pipeline(StandardScaler(),
                      PCA(n_components=2))
Ztr = model.fit_transform(Xtr)
Zte = model.transform(Xte)
print("Shapes:", Ztr.shape, Zte.shape)
print("Variance ratios:",
      model.named_steps["pca"].explained_variance_ratio_)
