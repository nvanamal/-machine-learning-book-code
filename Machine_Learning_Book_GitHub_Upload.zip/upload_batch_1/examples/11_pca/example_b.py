# PRINCIPAL COMPONENT ANALYSIS (PCA) | EXAMPLE B
# Held-out reconstruction from two components
# Dr. Nagendrababu Vanamala

from sklearn.datasets import load_iris
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.metrics import mean_squared_error
X, _ = load_iris(return_X_y=True)
Xtr, Xte = train_test_split(X, random_state=42)
scaler = StandardScaler().fit(Xtr)
A, B = scaler.transform(Xtr), scaler.transform(Xte)
pca = PCA(n_components=2).fit(A)
reconstructed = pca.inverse_transform(pca.transform(B))
print("Standardized reconstruction MSE:",
      mean_squared_error(B, reconstructed))
