# RECOMMENDER SYSTEMS | EXAMPLE B
# Latent user-item score matrix
# Dr. Nagendrababu Vanamala

import numpy as np
users = np.array([[1., 0.2], [0.1, 1.]])
items = np.array([[1., 0.], [0., 1.], [0.6, 0.6]])
scores = users @ items.T
print("User-item scores:", scores)
print("Best item per user:", scores.argmax(axis=1))
# Fixed embeddings illustrate scores; no factor training is claimed.
