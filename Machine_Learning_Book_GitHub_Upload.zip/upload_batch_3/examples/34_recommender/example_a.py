# RECOMMENDER SYSTEMS | EXAMPLE A
# Rank items by content similarity
# Dr. Nagendrababu Vanamala

import numpy as np
items = np.array([[1., 0.], [0., 1.], [0.8, 0.2]])
profile = np.array([1., 0.])
scores = items @ profile / (np.linalg.norm(items, axis=1) * np.linalg.norm(profile))
print("Content scores:", np.round(scores, 3))
print("Ranked item IDs:", np.argsort(-scores))
