# DROPOUT — Example B

**Evaluation disables the training mask**  
Book page: **113** · Author: **Dr. Nagendrababu Vanamala**

[Download / view the Python file](../../examples/27_dropout/example_b.py) · [All topics](../../README.md)

## What this example teaches

Randomly removes selected activations during training to regularize a network. Inverted dropout scales survivors by 1/(1-p), preserving the expected activation. At standard inference it is disabled.

## Python code

```python
import numpy as np
h = np.array([1., 2., 3.]); p = 0.5
training = False
rng = np.random.default_rng(42)
y = h * (rng.random(h.shape) >= p) / (1 - p) if training else h
print("Evaluation activations:", y)
```

## Line-by-line guide

The following layout matches the formatted code in the book; the downloadable script has equivalent Python operations.

| Line | Python code | Explanation |
| --- | --- | --- |
| 1 | `import numpy as np` | Import numerical array tools. |
| 2 | `h = np.array([1.0, 2.0, 3.0])` | Compute or initialize the hidden representation. |
| 3 | `p = 0.5` | Assign p for the next step. |
| 4 | `training = False` | Assign training for the next step. |
| 5 | `rng = np.random.default_rng(42)` | Create a reproducible random generator. |
| 6 | `y = h * (rng.random(h.shape) >= p) / (1 - p) if training else h` | Define or generate the corresponding targets. |
| 7 | `print('Evaluation activations:', y)` | Print the result shown in the output box. |

## Recorded output from the book

```text
Evaluation activations: [1. 2. 3.]
```

Captured with NumPy 2.3.5 and scikit-learn 1.8.0. Outputs can vary with versions and numerical libraries.

## Reading the output

Evaluation returns the original activations because training dropout is disabled.

## Try it yourself

Toggle the training flag and compare a single run with repeated runs.

## Important check

Leaving dropout active during ordinary prediction changes the intended inference behaviour.
