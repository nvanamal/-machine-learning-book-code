# DROPOUT — Example C

**Expected activation is approximately preserved**  
Book page: **114** · Author: **Dr. Nagendrababu Vanamala**

[Download / view the Python file](../../examples/27_dropout/example_c.py) · [All topics](../../README.md)

## What this example teaches

Randomly removes selected activations during training to regularize a network. Inverted dropout scales survivors by 1/(1-p), preserving the expected activation. At standard inference it is disabled.

## Python code

```python
import numpy as np
rng = np.random.default_rng(42)
p = 0.4
samples = (rng.random(10000) >= p) / (1 - p)
print("Empirical mean:", round(samples.mean(), 3))
print("Theoretical mean:", 1.0)
```

## Line-by-line guide

The following layout matches the formatted code in the book; the downloadable script has equivalent Python operations.

| Line | Python code | Explanation |
| --- | --- | --- |
| 1 | `import numpy as np` | Import numerical array tools. |
| 2 | `rng = np.random.default_rng(42)` | Create a reproducible random generator. |
| 3 | `p = 0.4` | Assign p for the next step. |
| 4 | `samples = (rng.random(10000) >= p) / (1 - p)` | Assign samples for the next step. |
| 5 | `print('Empirical mean:', round(samples.mean(), 3))` | Print the result shown in the output box. |
| 6 | `print('Theoretical mean:', 1.0)` | Print the result shown in the output box. |

## Recorded output from the book

```text
Empirical mean: 0.994
Theoretical mean: 1.0
```

Captured with NumPy 2.3.5 and scikit-learn 1.8.0. Outputs can vary with versions and numerical libraries.

## Reading the output

Many dropout samples have an empirical mean close to the original activation, as expected after scaling.

## Try it yourself

Increase the sample count and compare the empirical mean with one.

## Important check

Preserving the mean does not preserve each individual activation or eliminate added variance.
